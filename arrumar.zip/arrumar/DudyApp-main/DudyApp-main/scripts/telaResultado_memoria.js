const btnProx = document.getElementById('proxAtv');

btnProx.addEventListener('click', () => {
    window.location.href = '../telas/telaJogo_memoria.html';
});

const btnSair = document.getElementById('voltar');

btnSair.addEventListener('click', () => {
    window.location.href = '../telas/tela_escolhaJogos.html';
});

document.addEventListener('DOMContentLoaded', () => {
    const tempoFinal = localStorage.getItem('memoriaTime') || '00:00';
    const tempoElement = document.getElementById('tempoTxt');
    tempoElement.textContent = tempoFinal;
});