// URL e chave do Supabase
const SUPABASE_URL = "https://jqteyocpfokvjmsrdiea.supabase.co";
const SUPABASE_ANON_KEY = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImpxdGV5b2NwZm9rdmptc3JkaWVhIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NTU2MTQwNDIsImV4cCI6MjA3MTE5MDA0Mn0.SNBHJgmoXVIAx6d5uDIBU2OYfzIzyZMbqcigAuoSBtA";

// Criação do cliente Supabase
const supabaseClient = supabase.createClient(SUPABASE_URL, SUPABASE_ANON_KEY);

const subtitle = document.getElementById('subtitle'); 
const mostrarSenhaImg = document.getElementById('mostrarSenha');

subtitle.addEventListener('click', () => {
  window.location.href = '../telas/telaCadastro.html';
});

document.addEventListener("DOMContentLoaded", () => {
  const loginForm = document.getElementById("loginForm");
  const emailInput = document.getElementById("emailLogin");
  const senhaInput = document.getElementById("senhaLogin");
  const message = document.getElementById("message");

  // Mostrar/esconder senha
  mostrarSenhaImg.addEventListener('click', () => { 
    const fundo = mostrarSenhaImg.src; 
    if (fundo.includes('senhaFechado.svg')) { 
      mostrarSenhaImg.src = '../app_login/assets/senhaAberto.svg'; 
      senhaInput.type = 'text'; 
    } else { 
      mostrarSenhaImg.src = '../app_login/assets/senhaFechado.svg'; 
      senhaInput.type = 'password'; 
    } 
  });

  // LOGIN
  loginForm.addEventListener("submit", async (e) => {
    e.preventDefault();

    const email = emailInput.value.trim();
    const password = senhaInput.value.trim();

    if (!email || !password) {
      message.textContent = "Preencha todos os campos!";
      return;
    }

    try {
      // 1) Autentica no Auth
      const { data: authData, error: authError } = await supabaseClient.auth.signInWithPassword({
        email,
        password,
      });

      if (authError) {
        message.textContent = "Erro: " + authError.message;
        console.error(authError);
        return;
      }

      const user = authData.user;
      message.style.color = "green";
      message.textContent = "Login realizado com sucesso!";
      console.log("Usuário logado:", user);

      // 2) Busca na tabela responsavel pelo auth_id
      const { data: perfil, error: perfilError } = await supabaseClient
        .from("responsavel")
        .select("id, nome, email, auth_id")
        .eq("auth_id", user.id)
        .single();

      if (perfilError) {
        console.error("Erro ao buscar responsavel:", perfilError);
        message.textContent = "Não foi possível encontrar seu perfil no sistema.";
        return;
      }

      // 3) Guarda localmente
      localStorage.setItem("perfil", JSON.stringify(perfil));

      // 4) Redireciona conforme quantidade de crianças
      verificarRedirecionamento(perfil.id);

    } catch (err) {
      console.error("Erro inesperado:", err);
      message.textContent = "Ocorreu um erro, tente novamente.";
    }
  });
});

// Função para redirecionar com base na quantidade de crianças
async function verificarRedirecionamento(idResponsavel) {
  try {
    const { count, error: countError } = await supabaseClient
      .from('estudante')
      .select('id', { count: 'exact' })
      .eq('idresponsavel', idResponsavel);

    if (countError) {
      console.error('Erro ao contar as crianças:', countError);
      return;
    }

    if (count === 0) window.location.href = '../telas/telaCadKid.html';
    else if (count === 1) window.location.href = '../telas/telaCadKid1.html';
    else if (count === 2) window.location.href = '../telas/telaCadKid2.html';
    else window.location.href = '../telas/telaCadKid3.html';

  } catch (err) {
    console.error("Erro ao redirecionar:", err);
  }
}
