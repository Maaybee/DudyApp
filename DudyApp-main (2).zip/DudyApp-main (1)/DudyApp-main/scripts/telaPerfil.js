document.addEventListener('DOMContentLoaded', async () => {
    const progressoPreenchimento = document.getElementById('progresso-preenchimento');
    const textoProgresso = document.getElementById('progresso');
    const nivelTexto = document.getElementById('nivel');
    const nomePerfil = document.getElementById('nomePerfil');

    // Recupera o id da criança que foi salva ao clicar no perfil
    const idCrianca = localStorage.getItem("criancaSelecionada");

    if (!idCrianca) {
        alert("Nenhuma criança selecionada!");
        window.location.href = "../telas/telaLoginKid.html";
        return;
    }

    try {
        // Busca os dados da criança no Supabase
        const { data, error } = await supabaseClient
            .from("estudante")
            .select("nome, pontuacao") // ajuste os campos conforme sua tabela
            .eq("id", idCrianca)
            .single();

        if (error) throw error;

        // Atualiza o nome na tela
        nomePerfil.textContent = data.nome;

        // Atualiza progresso (se já tiver um campo de pontuação no banco)
        if (data.pontuacao !== undefined) {
            atualizarProgresso(data.pontuacao); 
        }

    } catch (err) {
        console.error("Erro ao carregar criança:", err);
    }

    // ---- Função de progresso (já existia no seu código) ----
    function atualizarProgresso(porcentagem) {
        const progressoAtual = Math.min(100, Math.max(0, porcentagem));
        progressoPreenchimento.style.width = `${progressoAtual}%`;
        textoProgresso.textContent = `${progressoAtual}%`;

        if (progressoAtual < 25) {
            nivelTexto.textContent = 'Iniciante';
        } else if (progressoAtual < 50) {
            nivelTexto.textContent = 'Básico';
        } else if (progressoAtual < 75) {
            nivelTexto.textContent = 'Intermediário';
        } else {
            nivelTexto.textContent = 'Avançado';
        }
    }

    // ---- Botão de voltar pra Home ----
    document.getElementById('btnHomeHome').addEventListener('click', function() {
        window.location.href = '../telas/telaHome.html'; 
    });
});
