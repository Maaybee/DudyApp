// Recupera o UUID do responsável do login
const idResponsavel = localStorage.getItem("id");

// Referência à div que vai conter os perfis
const listaCriançasDiv = document.getElementById("listaCrianças");

async function carregarCrianças() {
  const idResponsavel = localStorage.getItem("id");
  const listaCriançasDiv = document.getElementById("listaCrianças");

  if (!idResponsavel) {
    alert("Não foi possível identificar o responsável. Faça login novamente.");
    return;
  }

  try {
    const { data: crianças, error } = await supabaseClient
      .from("estudante")
      .select("nome, icone")
      .eq("id", idResponsavel);

    if (error) throw error;

    listaCriançasDiv.innerHTML = crianças.length === 0 
      ? "<p>Nenhuma criança cadastrada.</p>" 
      : "";

    crianças.forEach(crianca => {
      const perfilDiv = document.createElement("div");
      perfilDiv.classList.add("perfil_kid");
      perfilDiv.dataset.id = crianca.id; // guarda o id da criança no HTML

      const img = document.createElement("img");
      img.src = crianca.icone; // caminho correto
      img.alt = `Ícone de ${crianca.nome}`;
      
      const nomeH1 = document.createElement("h1");
      // Pega apenas o primeiro nome
      nomeH1.textContent = crianca.nome.split(" ")[0];

      const iconeDiv = document.createElement("div");
      iconeDiv.classList.add("icone");
      iconeDiv.appendChild(img);

      const nomeDiv = document.createElement("div");
      nomeDiv.classList.add("nome_kid");
      nomeDiv.appendChild(nomeH1);

      perfilDiv.appendChild(iconeDiv);
      perfilDiv.appendChild(nomeDiv);

      perfilDiv.addEventListener("click", () => { // adiciona evento de clique → redireciona para a Home
        localStorage.setItem("criancaSelecionada", crianca.id);
        window.location.href = "../telas/telaHome.html";
      });

      listaCriançasDiv.appendChild(perfilDiv);
    });

  } catch (err) {
    console.error("Erro ao buscar crianças:", err);
  }
}

document.addEventListener("DOMContentLoaded", carregarCrianças);

function cadastrar_redirecionamento () { 
  window.location.href = "../telas/telaCadKid.html";
}


function abrirMenu() {
  document.getElementById("menu").style.display = "block";
}

function fecharMenu() {
  document.getElementById("menu").style.display = "none";
}

async function logout() {
  try {
    // Faz logout no Supabase
    const { error } = await supabaseClient.auth.signOut();

    if (error) {
      console.error("Erro ao deslogar:", error);
      alert("Não foi possível sair. Tente novamente.");
      return;
    }

    // Limpa o localStorage (opcional, mas recomendado)
    localStorage.removeItem("id");

    // Redireciona para a tela de login
    window.location.href = "../index.html";

  } catch (err) {
    console.error("Erro inesperado ao sair:", err);
    alert("Ocorreu um erro. Tente novamente.");
  }
}
